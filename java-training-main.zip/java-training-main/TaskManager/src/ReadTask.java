import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.cj.xdevapi.PreparableStatement;

public class ReadTask {
     public void readTask(){
          try {
               Connection connection=DBConnection.getConnection();
          String query="select * from task";
          PreparedStatement ps = connection.prepareStatement(query);
          // executing query
          ResultSet rs = ps.executeQuery();
          System.out.println("Task deatils");
          while (rs.next()) {  
                System.out.println("Task Id: "+ rs.getInt("task_id"));
                System.out.println("Task Name: "+
                    rs.getString("task_name")
                );
                System.out.println("Task  description "+rs.getString("description"));
                System.out.println("Task status: "+rs.getString("status"));
                System.out.println("Task Assigned to: "+rs.getString("assigned_to"));
                System.out.println("Task created at: "+rs.getDate("created_at"));
                System.out.println("Task due date: "+rs.getDate("due_date"));
                
          }
          connection.close();
          } catch (Exception e) {
               System.out.println(e);
          }
     }
}
