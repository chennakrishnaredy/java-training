interface Payment{
    // abstract method
    void pay(String cardName);
}

class CreditCard implements Payment{
     public void pay(String cardName){
        System.out.println("Payment is done by creditcard "+ cardName);
    } 
}
class PaymentInterface{
      public static void main(String [] args){
        CreditCard credit = new CreditCard();
        credit.pay("Amazon icic");
      }
}