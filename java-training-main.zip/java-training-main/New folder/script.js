/*
// variables (var,let,const)
var firstName = "luffy";
console.log(firstName);
// var global scope and function scope
// problems with var
var firstName = "luffy";
var firstName = "js";
console.log(firstName);
// assign new values is possible
firstName = "mruh";
console.log(firstName);
// es6 let is (mutable)and const(immutable)
let age = 21;
console.log(age);
// let age = 100;
age = 100; //updating value
console.log(age);
// const we can't same variable again,assign new not possible
const birthYear = 1921;
console.log(birthYear);
// const birthYear = 1890;
// birthYear = 2000;
*/
// hosting  var variables and function declaration are hosted
console.log(name);
var name = "MonkeyDLuffy";
// console.log(a);
// let a = 10;
// console.log(b);
// const b = 10;
// datatype in primative data types (Number,bigInt,undefine,null,string,symbol)
