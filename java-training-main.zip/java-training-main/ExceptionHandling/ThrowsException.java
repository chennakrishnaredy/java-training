class ThrowsException{
    // throws are used to  throw multiple exceptions at time using (,)
    // we throws  at  method signature 
    static void  divide(int a,int b) throws ArithmeticException{
        System.out.println(a/b);
    }
    static void multi() throws ArrayIndexOutOfBoundsException,ArithmeticException{
        int num [] = {10,20,30};
        System.out.println(num[12]);
        System.out.println(num[1]/0);
    }
    public static void main(String []  args){
        // divide(4,0);
        multi();
    }
}