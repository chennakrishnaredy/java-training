class StringException{
     public static void main(String[] args){
        try{
        String anime = "onepiece";
        System.out.println(anime.charAt(11));
        String name = null;
        System.out.println(name.length());
        }catch(StringIndexOutOfBoundsException err){
            System.out.println(err);
        }catch(NullPointerException err){
            System.out.println(err);
        }finally {
            System.out.println("Java is fun 😁😁😆😅");
        }
     }
}