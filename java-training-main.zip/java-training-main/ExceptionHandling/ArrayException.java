class ArrayException {
    public static void main(String[] args){
        try{
        int [] num = {10,20,30};
        System.out.println(num[1]);
        System.out.println(num[num.length -1]);
        System.out.println(num[7]);
        int result = num[1] / 0;
        }catch(ArrayIndexOutOfBoundsException err) {
        System.out.println(err.getMessage());
        }
    }
}