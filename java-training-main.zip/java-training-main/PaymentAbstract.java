abstract class Payment{
    void Welcome(){
        System.out.println("Welcome to papal  payment gate way ");
    }
    // abtract method
    abstract void pay(String cardName);
}
class DebitCard extends Payment{
    void pay(String cardName){
        System.out.println("Payment is done by debit card "+ cardName);
    }
}
class PaymentAbstract{
    public static void main(String [] args){
        DebitCard debit= new DebitCard();
        debit.pay("axis online reward card");
    }
}