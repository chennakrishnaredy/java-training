import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
     public static Connection getConnection(){
          final String Url = "jdbc:mysql://localhost:3306/TaskManager";
          final String userName ="root";
          final String password = "kittu";
         try {
           // connect Driver
          Class.forName("com.mysql.cj.jdbc.Driver");
          return DriverManager.getConnection(Url,userName,password);
         } catch (Exception e) {
          System.out.println(e);
         }
         return null;
     }
}
