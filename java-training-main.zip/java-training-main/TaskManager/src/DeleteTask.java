import java.sql.Connection;
import java.sql.PreparedStatement;

public class DeleteTask {
     public void deleteTask(){
          try{
               Connection connection=DBConnection.getConnection();
               String query="delete from task where task_id=?";
               PreparedStatement ps=connection.prepareStatement(query);
               ps.setInt(1, 102);
               int rows = ps.executeUpdate();
               System.out.println(rows+" task Deleted ");

          }catch(Exception e) {System.err.println(e);}

     }
}
