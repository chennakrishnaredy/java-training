import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class readData {
         public static void main(String[] args) 
    {
        try{
            // driver connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            // connection
            Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/AIML","root","kittu");
            Statement statement =connection.createStatement();
            ResultSet resultSet=statement.executeQuery("select * from student");
            while(resultSet.next()){
               System.out.println(resultSet.getInt(1) + " "+resultSet.getString(2)+" "+resultSet.getInt(3));
            }
            connection.close();
        }catch(Exception err){
          System.out.println(err);
        }
}
}