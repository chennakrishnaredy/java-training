package com.example.demo;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class Test {
     // get method to retrieve data
     @GetMapping("/")
     public String home(){
          return "Welcome to Spring Boot Page";
     }
     @GetMapping("/welcome")
     public String welcome(){
          return "Welcome to RESTFULL API Concept";
     }
     // Query params or parameters or RequestParams
     @GetMapping("/user")
     public String userInfo(@RequestParam String name){
          return "User Name: "+name;
     }
     @GetMapping("/users")
     public String userData(@RequestParam int id,@RequestParam String name){
          return "User id: "+id + "and User name: "+name;
     }
     // dynamic params or path variables
     @GetMapping("/student/{id}")
     public String student(@PathVariable int id){
          return "Student id: "+id;
     }
     @GetMapping("/student/{name}/{id}")
     public String studentData(@PathVariable String name,@PathVariable int id){
          return "Student id: "+id +" and name: "+name;
     }
     // json data to client
     @GetMapping("/students")
     public Student studentInfo(){
          return new Student(650, "luffy", "windmill village");
     }
     @GetMapping("/studentsinfo")
     public List<Student> studentRecords(){
          return Arrays.asList(
          new Student(637, "kittu","hyd"),
          new Student(537, "Luffy", "Windmill village"),
          new Student(321, "zoro", "east blue"));
     }
}

class Student {
     private int id;
     private String name;
     private String address;
     public Student(int id,String name,String address){
          this.id = id;
          this.name=name;
          this.address=address;
     }
     public int getId(){
          return id;
     }
     public String getName(){
          return name;
     }
     public String getAddress(){
          return address;
     }

}
