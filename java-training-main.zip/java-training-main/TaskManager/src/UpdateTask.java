import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdateTask {
     public void updateTask(){
          try {
               Connection connection=DBConnection.getConnection();
          String query="update task set task_name=?,status=? where task_id=?";
          PreparedStatement ps=connection.prepareStatement(query);
          ps.setString(1, "Express js");
          ps.setString(2, "done");
          ps.setInt(3, 101);
          int rows =ps.executeUpdate();
          if(rows > 0){
               System.out.println(rows +" row is updated");
          }else{
               System.out.println("Failed to update");
          }
          } catch (Exception e) {
               System.err.println(e);
          }
     }
}
