// Polymorphsim -> poly many and morphim forms (1.compile time and runtime Polymorphsim)
class Polymorphsim{
    // 1.compile time (over loading)
    void add(int a){
        System.out.println(a);
    }
    void add(int a,int b){
        System.out.println(a+b);
    }
    void add(float a,float b,float c){
        System.out.println(a+b+c);
    }
public static void main(String[] args){
    // + 
    System.out.println(20 + 10);
    System.out.println(20 + "26");
    System.out.println("MonkeyD" + "Luffy");
    Polymorphsim poly = new Polymorphsim();
    poly.add(10);
    poly.add(10,20);
    poly.add(10f,20f,30f);

}
}