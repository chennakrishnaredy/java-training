import java.util.*;
class GeneralException{
    public static void main(String [] args){
        
        try(Scanner sc = new Scanner(System.in)){
        System.out.println("Enter a  value? ");
        int a = sc.nextInt();
        System.out.println("Enter b  value? ");
        int  b= sc.nextInt();
        System.out.println(a / b);
        System.out.println("Our file is successfully run without exception exc");
        // generation exception
        }catch(Exception err){
        System.out.println(err);
        }
    }
}