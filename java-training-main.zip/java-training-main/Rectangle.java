import java.util.*;
public class Rectangle{
    public static void main(String []args){
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter Length of rectangle: ");
        float length =sc.nextFloat();
         System.out.println("Enter width of rectangle: ");
        float width =sc.nextFloat();
        float area = length * width;
        System.out.println("Area of rectangle is "+ area)
        // bmi formula  weight /height *height
    }
}