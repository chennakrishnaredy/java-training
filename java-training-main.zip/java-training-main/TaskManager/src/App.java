public class App {
    public static void main(String[] args) {
        CreateTask create=new CreateTask();
        ReadTask read = new ReadTask();
        UpdateTask update =new UpdateTask();
        DeleteTask delete= new DeleteTask();
        System.out.println("===================create==================");
        // create.createTask();
        System.out.println("===================Read==================");
        read.readTask();
        System.out.println("===================Update==================");
        update.updateTask();
        System.out.println("===================Delete==================");
        delete.deleteTask();

    }
}
