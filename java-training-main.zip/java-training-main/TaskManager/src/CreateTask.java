import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class CreateTask {
     public void createTask(){
          try {
               Connection connection = DBConnection.getConnection();
          Statement statement = connection.createStatement();
          // create database
          statement.executeUpdate("CREATE DATABASE IF NOT EXISTS TaskManager");
          statement.executeUpdate("Use TaskManager");
          //create table code 
          String createTable = 
          "create table IF NOT EXISTS task ("
          +"task_id int primary key ,"
          +"task_name varchar(100) ,"
          +"description varchar(200) ,"
          +"status varchar(100) ,"
          +"assigned_to varchar(100) ,"
          +"created_at Date ,"
          +"due_date Date )";
          // creating table
          statement.executeUpdate(createTable);
          // insert records
          String query = "insert into task values(?,?,?,?,?,?,?)";
          PreparedStatement ps = connection.prepareStatement(query);
          ps.setInt(1, 102);
          ps.setString(2, "Spring connection");
          ps.setString(3, "use mysql connector to connect with spring");
          ps.setString(4, "Pending");
          ps.setString(5, "rk");
          ps.setDate(6, java.sql.Date.valueOf("2026-07-21"));
          ps.setDate(7, java.sql.Date.valueOf("2026-07-27"));
          int row = ps.executeUpdate();
          System.out.println(row +"  task is inserted successfully");
          connection.close();
          } catch (Exception e) {
               System.out.println( e);
          }
     }
}