/*const a = 10;
console.log(typeof a);
console.log(a);
const b = 20.5;
console.log(typeof b,b);
const bigNum = 100000n;
console.log(typeof bigNum,bigNum);
// undefine null
let job;
let spirit =undefined;
console.log(typeof job,job);
console.log(typeof spirit,spirit);
// const n;
// n = 10;
let n = null;
console.log(n,typeof n);
*/
// =(assign values),==loose(type coersion),===(strict)
console.log(10 == 10);
console.log("10" == 10);
console.log(true == 1);
console.log(true === 1);
console.log("10" === 10);
console.log(0 == false);
console.log(0 === false);
console.log();
console.log("20" == 20);
console.log(Number("20") === 20);
console.log(+"20" === 20);
console.log(1 && 0);
console.log(1 || 0);
console.log(undefined && 0);
// !=(==) and !==(===)
console.log("10" != 10);
console.log(10 != "20");
console.log("10" !== 10);
// input
const a = prompt("enter a value");
console.log(typeof a, a);
// type casting
const b = +prompt("enter b value");
console.log(typeof b, b);
