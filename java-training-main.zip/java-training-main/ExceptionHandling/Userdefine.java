class Userdefine{
    static void Custhom(){
        int a= 2;
        if(a < 18) {
            throw new ArithmeticException(" You can't apply lic..");
        }
        System.out.println("Done");
    }
    public static void main(String [] args) {
        // throw are used for throw exceptions manual or explicitly 
        // throw inside method body
        // at time we can throw one exception
    Custhom();
    }
}