import java.util.*;
class specificExceptions{
    public static void main(String[] args){
        try(Scanner sc = new Scanner(System.in)){
            System.out.println("Enter a number? ");
            int num = sc.nextInt();
            System.out.println(num/ num);
        }catch(InputMismatchException err){
            System.out.println("Wrong input value: "+ err);
        }catch(ArithmeticException err){
            System.out.println("we can't divided by zero: "+ err);
            // write general exception as last catch block for try
        }catch(Exception  err){
            System.out.println(err)
        }
    }
}