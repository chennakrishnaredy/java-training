import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class App {
    public static void main(String[] args) 
    {
        try{
            // driver connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            // connection
            Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/AIML","root","kittu");
            String query = "insert into student values(?,?,?)";
            PreparedStatement ps=connection.prepareStatement(query);
            ps.setInt(1, 102);
            ps.setString(2, "zoro");
            ps.setInt(3, 25);
            ps.executeUpdate();
            System.out.println("inserted data");
            connection.close();
        }catch(Exception err){
            System.out.println(err);
        }
    }
}
